package paquete04;

import java.io.Serializable;

public class Ciudad implements Serializable {
    
    private String nombreCiudad;
    private String nombreProvincia;
    
    public Ciudad(String n, String p) {
        nombreCiudad= n;
        nombreProvincia = p;
        
    }
    
    public void establecerNombreCiudad(String n) {
        nombreCiudad = n;
        
    }
    
    public void establecerNombreProvincia(String p) {
        nombreProvincia= p;
        
    }
    
    public String obtenerNombreCiudad() {
        return nombreCiudad;
        
    }
    
    public String obtenerProvincia() {
        return nombreProvincia;
        
    }    
}
