package paquete01;

import java.util.Scanner;
import Write_Read.*;
import paquete02.*;
import paquete03.*;
import paquete04.*;
import paquete05.*;

public class Ejecutor {

    public static void main(String[] args) {

        Scanner leer = new Scanner(System.in);

        int opc;      
        
        boolean bandera = true;
        while (bandera) {

            opc = menu();

            switch (opc) {
                case 1:
                    agregarPropietario();
                break;    
                case 2:
                    verPropietario();
                break;    
                case 3:
                    agregarBarrio();
                break;    
                case 4:
                    verBarrio();
                break;    
                case 5:
                    agregarCiudad();
                break;    
                case 6:
                    verCiudad();
                break;    
                case 7:
                    agregarCasa();
                break;    
                case 8:
                    verCasa();
                break;    
                case 9:
                    agregarDepartamento();
                break;    
                case 10:
                    verDepartamento();
                break;    
                default:
                    System.out.println(" INGRESE UNA OPCION VALIDA ");
            }
            
            leer.nextLine();
            System.out.println("Ingrese 'si' si desea salir del Sistema");
            String salida = leer.nextLine();
            if (salida.equals("si")) {
                bandera = false;
            }
        }
    }

    public static int menu() {

        Scanner leer = new Scanner(System.in);

        System.out.println("      SISTEMA DE GESTION\n");
        System.out.println(" Ingresar Propietario       [1]");
        System.out.println(" Listar Propietario         [2]");
        System.out.println("-------------------------------");
        System.out.println(" Ingresar Barrio            [3]");
        System.out.println(" Listar Barrio              [4]");
        System.out.println("-------------------------------");
        System.out.println(" Ingresar Ciudad            [5]");
        System.out.println(" Listar Ciudad              [6]");
        System.out.println("-------------------------------");
        System.out.println(" Ingresar Casa              [7]");
        System.out.println(" Listar Casa                [8]");
        System.out.println("-------------------------------");
        System.out.println(" Ingresar Departamento      [9]");
        System.out.println(" Listar Departamentmento    [10]");

        return leer.nextInt();
    }

    /*-----------------------------------------------------------------------*/
    
    public static void agregarPropietario() {

        Scanner leer = new Scanner(System.in);

        String nombreArchivo = "data/lospropietarios.dat";

        String nombres, apellidos, identificacion;

        System.out.print(" Nombres Del Propietario:  ");
        nombres = leer.nextLine();
        System.out.print(" Apellidos Del Propietario:  ");
        apellidos = leer.nextLine();
        System.out.print(" Identificacion Del Propietarios:  ");
        identificacion = leer.nextLine();

        Propietario propietarios = new Propietario(nombres, apellidos,
                identificacion);

        EscrituraArchivoSecuencialPropietario archivo
                = new EscrituraArchivoSecuencialPropietario(nombreArchivo);
        archivo.establecerRegistro(propietarios);
        archivo.establecerSalida();

    }

    public static void verPropietario() {

        String nombreArchivo = "data/lospropietarios.dat";

        LecturaArchivoSecuencialPropietario lectura
                = new LecturaArchivoSecuencialPropietario(nombreArchivo);
        lectura.establecerListaPropietario();

        System.out.println(lectura);

    }

    public static void agregarBarrio() {

        Scanner leer = new Scanner(System.in);

        String nombreArchivo = "data/losbarrios.dat";

        String nombreBarrio, referencia;

        System.out.print(" Nombres Del Barrio:  ");
        nombreBarrio = leer.nextLine();
        System.out.print(" Apellidos Del Referencia:  ");
        referencia = leer.nextLine();

        Barrio barrios = new Barrio(nombreBarrio, referencia);

        EscrituraArchivoSecuencialBarrio archivo
                = new EscrituraArchivoSecuencialBarrio(nombreArchivo);
        archivo.establecerRegistro(barrios);
        archivo.establecerSalida();

    }

    public static void verBarrio() {

        String nombreArchivo = "data/losbarrios.dat";

        LecturaArchivoSecuencialBarrio lectura
                = new LecturaArchivoSecuencialBarrio(nombreArchivo);
        lectura.establecerListaBarrio();

        System.out.println(lectura);

    }

    public static void agregarCiudad() {

        Scanner leer = new Scanner(System.in);

        String nombreArchivo = "data/lasciudades.dat";

        String nombreCiudad, nombrePronvicia;

        System.out.print(" Nombres De La Ciudad:  ");
        nombreCiudad = leer.nextLine();
        System.out.print(" Nombre De La Provincia:  ");
        nombrePronvicia = leer.nextLine();

        Ciudad ciudades = new Ciudad(nombreCiudad, nombrePronvicia);

        EscrituraArchivoSecuencialCiudad archivo
                = new EscrituraArchivoSecuencialCiudad(nombreArchivo);
        archivo.establecerRegistro(ciudades);
        archivo.establecerSalida();

    }

    public static void verCiudad() {

        String nombreArchivo = "data/lasciudades.dat";

        LecturaArchivoSecuencialCiudad lectura
                = new LecturaArchivoSecuencialCiudad(nombreArchivo);
        lectura.establecerListaCiudad();

        System.out.println(lectura);

    }

    public static void agregarCasa() {

        Scanner leer = new Scanner(System.in);

        String nombreArchivo = "data/miscasas.dat";

        String nombres, apellidos, identificacion, nomCiudad, nomProvicnia;
        double precioMCuadrado, numMetrosCuadrados;
        int numCuartos;

        System.out.print(" Nombres Del Propietario:  ");
        nombres = leer.nextLine();
        System.out.print(" Apellidos Del Propietario:  ");
        apellidos = leer.nextLine();
        System.out.print(" Identificacion Del Propietarios:  ");
        identificacion = leer.nextLine();
        leer.nextLine(); // buffer

        System.out.print(" Precio Por Metro Cuadrado:  ");
        precioMCuadrado = leer.nextDouble();
        System.out.print(" Numero De Metros Cuadrados:  ");
        numMetrosCuadrados = leer.nextDouble();

        System.out.print(" Nombre De La Ciudad:  ");
        nomCiudad = leer.nextLine();
        System.out.print(" Nombre De La Provincia:  ");
        nomProvicnia = leer.nextLine();
        leer.nextLine(); // buffer

        System.out.print(" Numero De Cuartos:  ");
        numCuartos = leer.nextInt();

        Propietario propietarios = new Propietario(nombres,
                apellidos, identificacion);
        Ciudad ciudades = new Ciudad(nomCiudad, nomProvicnia);

        Casa casas = new Casa(propietarios, precioMCuadrado,
                numMetrosCuadrados, ciudades, numCuartos);

        EscrituraArchivoSecuencialCasa archivo
                = new EscrituraArchivoSecuencialCasa(nombreArchivo);
        archivo.establecerRegistro(casas);
        archivo.establecerSalida();

    }

    public static void verCasa() {

        String nombreArchivo = "data/miscasas.dat";

        LecturaArchivoSecuencialCasa lectura
                = new LecturaArchivoSecuencialCasa(nombreArchivo);
        lectura.establecerListaCasa();

        System.out.println(lectura);

    }

    public static void agregarDepartamento() {

        Scanner leer = new Scanner(System.in);

        String nombreArchivo = "data/departamentos.dat";

        String identificacion, nomBarrio, nomEdificio, ubiEdifcio;
        double precioMCuadrado, numMetrosCuadrados, vAlicuotaMensual;
       
        System.out.print(" Identificacion Del Propietario:  ");
        identificacion = leer.nextLine();
        leer.nextLine(); // buffer
        
        LecturaArchivoSecuencialPropietario p
                = new LecturaArchivoSecuencialPropietario("data/lospropietarios.dat");
        p.establecerIdentificador(identificacion);
        p.establecerPropietarioBuscado();
        Propietario ps = p.obtenerPropietarioBuscado();

        System.out.print(" Precio Por Metro Cuadrado:  ");
        precioMCuadrado = leer.nextDouble();
        System.out.print(" Numero De Metros Cuadrados:  ");
        numMetrosCuadrados = leer.nextDouble();

        System.out.print(" Valor Alicuota Mensual:  ");
        vAlicuotaMensual = leer.nextDouble();
        leer.nextLine(); // buffer

        System.out.print(" Nombre Del Barrio:  ");
        nomBarrio = leer.nextLine();
        LecturaArchivoSecuencialBarrio b = 
                new LecturaArchivoSecuencialBarrio("data/losbarrios.dat");
        b.establecerIdentificadorBarrio(nomBarrio);
        b.establecerBarrioBuscado();
        Barrio ba = b.obtenerBarrioBuscado();
        

        System.out.print(" Ubicacion Del Edificio:  ");
        ubiEdifcio = leer.nextLine();
        System.out.print(" Nombre Del Edificio:  ");
        nomEdificio = leer.nextLine();

        Departamento departamentos = new Departamento(ps,
                numMetrosCuadrados, precioMCuadrado, vAlicuotaMensual, ba,
                nomEdificio, ubiEdifcio);

        EscrituraArchivoSecuencialDepartamento archivo
                = new EscrituraArchivoSecuencialDepartamento(nombreArchivo);
        archivo.establecerRegistro(departamentos);
        archivo.establecerSalida();

    }

    public static void verDepartamento() {

        String nombreArchivo = "data/departamentos.dat";

        LecturaArchivoSecuencialDepartamento lectura
                = new LecturaArchivoSecuencialDepartamento(nombreArchivo);
        lectura.establecerListaDepartamentos();

        System.out.println(lectura);

    }
}
