package paquete02;

import java.io.Serializable;

public class Propietario implements Serializable{
    
    private String nombres;
    private String apellidos;
    private String identificacion;

    public Propietario(String n, String a, String i) {
        nombres = n;
        apellidos = a;
        identificacion = i;
        
    }
    
    public void establecerNombres(String n) {
        nombres = n;
        
    }
    
    public void establecerApellidos(String n) { 
        apellidos = n;
        
    }
    
    public void establecerIdentificacion(String n) { 
        identificacion = n;
        
    }
    
    public String obtenerNombres() { 
        return nombres;
        
    }
    
    public String obtenerApellidos() {  
        return apellidos;
        
    }
    
    public String obtenerIdentificacion() { 
        return identificacion;
        
    }
}
