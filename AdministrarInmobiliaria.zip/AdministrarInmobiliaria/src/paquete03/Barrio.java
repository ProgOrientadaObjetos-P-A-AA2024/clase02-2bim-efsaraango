package paquete03;

import java.io.Serializable;

public class Barrio implements Serializable {

    private String nombreBarrio;
    private String referencia;

    public Barrio(String n, String a) {
        nombreBarrio = n;
        referencia = a;
        
    }
    
    public void establecerNombreBarrio(String n) {
        nombreBarrio = n;
        
    }
    
    public void establecerReferencia(String n) { 
        referencia = n;
        
    }
    
    public String obtenerNombreBarrio() { 
        return nombreBarrio;
        
    }
    
    public String obtenerReferencia() {  
        return referencia;
        
    } 
}
