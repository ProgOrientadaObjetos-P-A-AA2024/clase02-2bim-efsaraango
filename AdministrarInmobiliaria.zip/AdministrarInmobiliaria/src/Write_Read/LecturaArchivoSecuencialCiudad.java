/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Write_Read;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import java.util.ArrayList;
import paquete00.AppendingObjectInputStream;
import paquete04.*;

/**
 *
 * @author reroes
 */
public class LecturaArchivoSecuencialCiudad {

    private ObjectInputStream entrada;
    private ArrayList<Ciudad> propietarisos;
    private String nombreArchivo;
    private String ciudad;
    private Ciudad ciudadBuscada;

    public LecturaArchivoSecuencialCiudad(String n) {
        nombreArchivo = n;
        File f = new File(nombreArchivo);
        if (f.exists()) {
            try // abre el archivo
            {
                entrada = new AppendingObjectInputStream(
                        new FileInputStream(n));
            } // fin de try
            catch (IOException ioException) {
                System.err.println("Error al abrir el archivo.");

            } // fin de catch
        }
    }

    public void establecerNombreArchivo(String n) {
        nombreArchivo = n;
    }

    public void establecerListaCiudad() {
        // 
        propietarisos = new ArrayList<>();
        File f = new File(obtenerNombreArchivo());
        if (f.exists()) {

            while (true) {
                try {
                    Ciudad registro = (Ciudad) entrada.readObject(); // casting
                    propietarisos.add(registro);
                } catch (EOFException endOfFileException) {
                    return; // se llegó al fin del archivo

                } catch (IOException ex) {
                    System.err.println("Error al leer el archivo: " + ex);
                } catch (ClassNotFoundException ex) {
                    System.err.println("No se pudo crear el objeto: " + ex);
                } catch (Exception ex) {
                    // System.err.println("No hay datos en el archivo: " + ex);
                    break;
                }
            }
        }

    }
    
    public void establecerIdentificadorCiudad(String n) {
        ciudad = n;
    }
    
    public void establecerCiudadBuscada() {
    
        File f = new File(obtenerNombreArchivo());
        if (f.exists()) {

            while (true) {
                try {
                    Ciudad registro = (Ciudad) entrada.readObject(); // casting
                    System.out.println(registro.obtenerNombreCiudad());
                    if(registro.obtenerNombreCiudad().equals(ciudad)){
                        ciudadBuscada = registro;
                        break;
                    }
                    
                } catch (EOFException endOfFileException) {
                    return;
                    
                } catch (IOException ex) {
                    System.err.println("Error al leer el archivo: " + ex);
                } catch (ClassNotFoundException ex) {
                    System.err.println("No se pudo crear el objeto: " + ex);
                } catch (Exception ex) {
                    System.err.println("No hay datos en el archivo: " + ex);

                }
            }
        }
    }

    public ArrayList<Ciudad> obtenerListaCiudad() {
        return propietarisos;
    }

    public String obtenerNombreArchivo() {
        return nombreArchivo;
    }
    
    public String obtenerIdentificadorCiudad() {
        return ciudad;
    }
    
    public Ciudad obtenerCiudadBuscada() {
        return ciudadBuscada;
    }

    @Override
    public String toString() {
        String cadena = "Ciudad\n";
        for (int i = 0; i < obtenerListaCiudad().size(); i++) {
            Ciudad p = obtenerListaCiudad().get(i);
            cadena = String.format("%s(%d) %s - %s\n", cadena, (i+1),
                   p.obtenerNombreCiudad(), p.obtenerProvincia());
        }

        return cadena;
    }

    // cierra el archivo y termina la aplicación
    public void cerrarArchivo() {
        try // cierra el archivo y sale
        {
            if (entrada != null) {
                entrada.close();
            }
            System.exit(0);
        } // fin de try
        catch (IOException ioException) {
            System.err.println("Error al cerrar el archivo.");
            System.exit(1);
        } // fin de catch
    } // fin del método cerrarArchivo
}
