/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Write_Read;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import java.util.ArrayList;
import paquete00.AppendingObjectInputStream;
import paquete03.*;

/**
 *
 * @author reroes
 */
public class LecturaArchivoSecuencialBarrio {

    private ObjectInputStream entrada;
    private ArrayList<Barrio> propietarisos;
    private String nombreArchivo;
    private String barrio;
    private Barrio barrioBuscada;

    public LecturaArchivoSecuencialBarrio(String n) {
        nombreArchivo = n;
        File f = new File(nombreArchivo);
        if (f.exists()) {
            try // abre el archivo
            {
                entrada = new AppendingObjectInputStream(
                        new FileInputStream(n));
            } // fin de try
            catch (IOException ioException) {
                System.err.println("Error al abrir el archivo.");

            } // fin de catch
        }
    }

    public void establecerNombreArchivo(String n) {
        nombreArchivo = n;
    }

    public void establecerListaBarrio() {
        // 
        propietarisos = new ArrayList<>();
        File f = new File(obtenerNombreArchivo());
        if (f.exists()) {

            while (true) {
                try {
                    Barrio registro = (Barrio) entrada.readObject();
                    propietarisos.add(registro);
                } catch (EOFException endOfFileException) {
                    return; // se llegó al fin del archivo

                } catch (IOException ex) {
                    System.err.println("Error al leer el archivo: " + ex);
                } catch (ClassNotFoundException ex) {
                    System.err.println("No se pudo crear el objeto: " + ex);
                } catch (Exception ex) {
                    // System.err.println("No hay datos en el archivo: " + ex);
                    break;
                }
            }
        }

    }
    
    public void establecerIdentificadorBarrio(String n) {
        barrio = n;
    }
    
    public void establecerBarrioBuscado() {
    
        File f = new File(obtenerNombreArchivo());
        if (f.exists()) {

            while (true) {
                try {
                    Barrio registro = (Barrio) entrada.readObject(); // casting
                    System.out.println(registro.obtenerNombreBarrio());
                    if(registro.obtenerNombreBarrio().equals(barrio)){
                        barrioBuscada = registro;
                        break;
                    }
                    
                } catch (EOFException endOfFileException) {
                    return;
                    
                } catch (IOException ex) {
                    System.err.println("Error al leer el archivo: " + ex);
                } catch (ClassNotFoundException ex) {
                    System.err.println("No se pudo crear el objeto: " + ex);
                } catch (Exception ex) {
                    System.err.println("No hay datos en el archivo: " + ex);

                }
            }
        }
    }

    public ArrayList<Barrio> obtenerListaBarrio() {
        return propietarisos;
    }

    public String obtenerNombreArchivo() {
        return nombreArchivo;
    }
    
    public String obtenerIdentificadorBarrio() {
        return barrio;
    }
    
    public Barrio obtenerBarrioBuscado() {
        return barrioBuscada;
    }

    @Override
    public String toString() {
        String cadena = "Barrio\n";
        for (int i = 0; i < obtenerListaBarrio().size(); i++) {
            Barrio p = obtenerListaBarrio().get(i);
            cadena = String.format("%s(%d) %s - %s\n", cadena, (i+1),
                   p.obtenerNombreBarrio(), p.obtenerReferencia());
        }

        return cadena;
    }

    // cierra el archivo y termina la aplicación
    public void cerrarArchivo() {
        try // cierra el archivo y sale
        {
            if (entrada != null) {
                entrada.close();
            }
            System.exit(0);
        } // fin de try
        catch (IOException ioException) {
            System.err.println("Error al cerrar el archivo.");
            System.exit(1);
        } // fin de catch
    } // fin del método cerrarArchivo
}
