/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Write_Read;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import java.util.ArrayList;
import paquete00.AppendingObjectInputStream;
import paquete02.*;

/**
 *
 * @author reroes
 */
public class LecturaArchivoSecuencialPropietario {

    private ObjectInputStream entrada;
    private ArrayList<Propietario> propietarisos;
    private String nombreArchivo;
    private String identificador;
    private Propietario propietarioBuscado;

    public LecturaArchivoSecuencialPropietario(String n) {
        nombreArchivo = n;
        File f = new File(nombreArchivo);
        if (f.exists()) {
            try // abre el archivo
            {
                entrada = new AppendingObjectInputStream(
                        new FileInputStream(n));
            } // fin de try
            catch (IOException ioException) {
                System.err.println("Error al abrir el archivo.");

            } // fin de catch
        }
    }

    public void establecerNombreArchivo(String n) {
        nombreArchivo = n;
    }

    public void establecerListaPropietario() {
        
        propietarisos = new ArrayList<>();
        File f = new File(obtenerNombreArchivo());
        if (f.exists()) {

            while (true) {
                try {
                    Propietario registro = (Propietario) entrada.readObject(); // casting
                    propietarisos.add(registro);
                } catch (EOFException endOfFileException) {
                    return; // se llegó al fin del archivo

                } catch (IOException ex) {
                    System.err.println("Error al leer el archivo: " + ex);
                } catch (ClassNotFoundException ex) {
                    System.err.println("No se pudo crear el objeto: " + ex);
                } catch (Exception ex) {
                    // System.err.println("No hay datos en el archivo: " + ex);
                    break;
                }
            }
        }
    }
    
    public void establecerIdentificador(String n) {
        identificador = n;
    }

    public void establecerPropietarioBuscado() {
    
        File f = new File(obtenerNombreArchivo());
        if (f.exists()) {

            while (true) {
                try {
                    Propietario registro = (Propietario) entrada.readObject(); // casting
                    System.out.println(registro.obtenerIdentificacion());
                    if(registro.obtenerIdentificacion().equals(identificador)){
                        propietarioBuscado = registro;
                        break;
                    }
                    
                } catch (EOFException endOfFileException) {
                    return;
                    
                } catch (IOException ex) {
                    System.err.println("Error al leer el archivo: " + ex);
                } catch (ClassNotFoundException ex) {
                    System.err.println("No se pudo crear el objeto: " + ex);
                } catch (Exception ex) {
                    System.err.println("No hay datos en el archivo: " + ex);

                }
            }
        }
    }

    public ArrayList<Propietario> obtenerListaPropietario() {
        return propietarisos;
    }

    public String obtenerNombreArchivo() {
        return nombreArchivo;
    }
    
    public String obtenerIdentificador() {
        return identificador;
    }
    
    public Propietario obtenerPropietarioBuscado() {
        return propietarioBuscado;
    }

    @Override
    public String toString() {
        String cadena = "Club\n";
        for (int i = 0; i < obtenerListaPropietario().size(); i++) {
            Propietario p = obtenerListaPropietario().get(i);
            cadena = String.format("%s(%d) %s - %s - %s\n", cadena, (i+1),
                   p.obtenerNombres(), 
                   p.obtenerApellidos(), 
                   p.obtenerIdentificacion());
        }

        return cadena;
    }

    // cierra el archivo y termina la aplicación
    public void cerrarArchivo() {
        try // cierra el archivo y sale
        {
            if (entrada != null) {
                entrada.close();
            }
            System.exit(0);
        } // fin de try
        catch (IOException ioException) {
            System.err.println("Error al cerrar el archivo.");
            System.exit(1);
        } // fin de catch
    } // fin del método cerrarArchivo
}
