package paquete05;

import java.io.Serializable;
import paquete02.Propietario;
import paquete03.Barrio;

public class Departamento implements Serializable {
    
    private Propietario propietarios;
    private double precioMetroCuadrado;
    private double numMetrosCuadrados;
    private double vAlicuotaMensual;
    private double costoFinal;
    private Barrio barrio;
    private String nomEdificio;
    private String ubiEdificio;
    
    public Departamento(Propietario p, double pmc, double nmc, double vam,
            Barrio b, String nE, String ubiE) {

        propietarios = p;
        precioMetroCuadrado = pmc;
        numMetrosCuadrados = nmc;
        vAlicuotaMensual = vam;
        barrio = b;
        nomEdificio = nE;
        ubiEdificio = ubiE;

    }
    
    public void establecerPropietario(Propietario p) {
        propietarios = p;
        
    }
    
    public void establecerPrecioMetroCuadrado(double pmc) {
        precioMetroCuadrado = pmc;
        
    }
    
    public void establecerNumMetroCuadrado(double nmc) {
        numMetrosCuadrados = nmc;
        
    }
    
    public void establecerValorAlicuataMensual(double vam) {
        vAlicuotaMensual = vam;
        
    }
    
    // metodo para calcular Costo Final
    public void establecerCostoFinal(double cF) {
        costoFinal = (obtenerNumMetroCuadrado() * obtenerPrecioMetroCuadrado() 
                + (obtenerValorAlicuataMensual() * 12) * 5);
        
    }
    
    public void establecerBarrio(Barrio b) {
        barrio = b;
        
    }
    
    public void establecerNombreEdificio(String nE) {
        nomEdificio = nE;
        
    }
    
    public void establecerUbicacionEdificio(String ubiE) {
        ubiEdificio = ubiE;
        
    }
    
    public Propietario obtenerPropietario() {
        return propietarios;
        
    }
    
    public double obtenerPrecioMetroCuadrado() {
        return precioMetroCuadrado;
        
    }
    
    public double obtenerNumMetroCuadrado() {
        return numMetrosCuadrados;
        
    }
    
    public double obtenerValorAlicuataMensual() {
        return vAlicuotaMensual;
        
    }
    
    public double obtenerCostoFinal() {
        return costoFinal;
        
    }
    
    public Barrio obtenerBarrio() {
        return barrio;
        
    }
    
    public String obtenerNombreEdificio() {
        return nomEdificio;
        
    }
    
    public String obetenerUbicacionEdificio() {
        return ubiEdificio;
        
    }
}
