package paquete05;

import java.io.Serializable;
import paquete02.Propietario;
import paquete04.Ciudad;

public class Casa implements Serializable {
    
    private Propietario propietario;
    private double precioMetroCuadrado;
    private double numMetrosCuadrados;
    private double costoFinal;
    private Ciudad ciudad;
    private int numCuartos;
    
    public Casa(Propietario p, double pmc, double nmc, Ciudad c, int nc) {
        propietario = p;
        precioMetroCuadrado = pmc;
        numMetrosCuadrados = nmc;
        ciudad = c;
        numCuartos = nc;

    }
    
    public void establecerPropietario(Propietario p) {
        propietario = p;
        
    }
    
    public void establecerPrecioMetroCuadrado(double pmc) {
        precioMetroCuadrado = pmc;
        
    }
    
    public void establecerNumMetroCuadrado(double nmc) {
        numMetrosCuadrados = nmc;
        
    }
    
    // metodo para calcular Costo Final
    public void calcularCostoFinal() {
        costoFinal = obtenerNumMetroCuadrado() * obtenerPrecioMetroCuadrado() 
                + 3000;
        
    }
    
    public void establecerCiudad(Ciudad c) {
        ciudad = c;
        
    }
    
    public void establecerNumCuartos(int nc) {
        numCuartos = nc;
        
    }
    
    public Propietario obtenerPropietario() {
        return propietario;
        
    }
    
    public double obtenerPrecioMetroCuadrado() {
        return precioMetroCuadrado;
        
    }
    
    public double obtenerNumMetroCuadrado() {
        return numMetrosCuadrados;
        
    }
    
    public double obtenerCostoFinal() {
        return costoFinal;
        
    }
    
    public Ciudad obtenerCiudad() {
        return ciudad;
        
    }
    
    public int obtenerNumCuartos() {
        return numCuartos;
        
    }  
}
